Name: Patrick Dunlap
Assignment 3 is to use CSS to mimick a page given in the assignment.
Link: https://www.cs.uml.edu/~pdunlap/HW3