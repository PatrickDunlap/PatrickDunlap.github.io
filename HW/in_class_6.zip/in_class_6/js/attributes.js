$(function() {
$("li:nth-child(3)").removeClass("hot"); //find third element and remove class
$("li.hot").addClass("favorite")
});