$(function() {

    $("#two").text("almonds"); //change text in second element
    $(".hot#two").html("<em>almonds</em>"); //update to have em tag
    $(".hot#three").html("<em>honey</em>");
    $("li#one").remove(); //remove item from the list


	
	
	

});