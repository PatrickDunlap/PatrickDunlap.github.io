In this assignment, I used a bootstrap template at this link https://builder.startbootstrap.com/builder/freelancer to greatly
the user interface to not be as simplistic. The user interface looks much sleeker. In the bootstrap template code,
I changed the text, and I changed the images in the portfolio to saw Homework followed by a number by making custom JPGs in photoshop.
I adjusted the links of all the homeworks, and included descriptions of what was done in the assigment, included either a link 
or a download link. Several hours was devoted to tinkering with the formatting to get it look a particular way. I had to add elements to the page.